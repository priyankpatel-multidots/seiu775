<?php
/**
 * @author OnTheGo Systems
 */
interface IWPML_REST_Action_Loader extends IWPML_Action_Loader_Factory {

}
