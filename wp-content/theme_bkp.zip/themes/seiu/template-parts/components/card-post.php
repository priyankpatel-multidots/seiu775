<?php
  // Note: this component expects a variable called
  // $card_post to be available on the same scope.
  $post_id = $card_post->ID;
  $post_title = $card_post->post_title;
  $post_url = get_permalink( $post_id );
  $post_type = get_post_type($card_post);
  $post_date = get_the_date('', $card_post);
  
  $post_image = get_the_post_thumbnail_url($post_id, 'medium_large');
  $excerpt = $card_post->post_excerpt;
  $description_part = get_the_content($post_id);
  $news_source = get_field('news_source', $card_post);
?>

<figure class="card card--post card--default-post card--post-index-<?= $i ?> <?php if (!empty($post_image)) : ?>card--has-image<?php endif; ?>"
  <?php if(!empty($has_animation) && $has_animation) : ?>
  data-aos="fade-top" data-aos-duration="<?= $i ?>000"
  <?php endif; ?>
  >
  <?php if (!empty($post_image)) : ?>
  <div class="card__img-wrapper">
      <a href="<?= $post_url ?>">
          <img
                  class="card__img lazy"
                  src="<?= $post_image; ?>"
                  data-src="<?= $post_image; ?>"
                  data-srcset="<?= $post_image; ?>"
                  alt="<?= esc_attr(get_post_meta(get_post_thumbnail_id($post_id, 'medium_large'), '_wp_attachment_image_alt', true)); ?>"
          />
      </a>
  </div>
  <?php endif; ?>

  <div class="card__content">
    <p
      class="card__date"><?php if ($news_source['source_name']): ?><?php if ($news_source['source_link']): ?><a href="<?php echo $news_source['source_link']; ?>"><?php endif; ?><?php echo $news_source['source_name']; ?><?php if ($news_source['source_link']): ?></a><?php endif; ?><?php if ($news_source['show_post_date']): ?> | <?php endif; ?><?php endif; ?><?php if ($news_source['show_post_date']): ?><?= $post_date; ?><?php endif; ?>
    </p>    <?php if ($post_title) : ?>
      <h4 class="card__title"><a href="<?= $post_url ?>"><?= $post_title; ?></a></h4>
    <?php endif; ?>

    <?php if (!empty($excerpt)) : ?>
      <div class="card__excerpt"><?= $excerpt; ?></div>
    <?php endif; ?>

    <a class="btn btn--text" href="<?= $post_url ?>">Read more</a>
  </div>


</figure>
