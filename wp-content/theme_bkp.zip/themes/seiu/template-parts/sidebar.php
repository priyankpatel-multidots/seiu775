<?php

	$query  = new WP_Query(array(
	  'posts_per_page' => 4,
	  'meta_key' => 'wpb_post_views_count',
	  'orderby' => 'meta_value_num',
	  'order' => 'DESC'
	));

	if( $query->have_posts() ) {
	  $most_popular_posts = $query->posts;
	}

	$sidebar = get_field('news_post_sidebar', 'option');
	$featured_post_repeater = $sidebar['popular_posts'];
?>

<div class="sidebar">
	<div class="sidebar__widget media-contact">
		<h3><?php echo $sidebar['news_sidebar_heading']; ?></h3>
	<?php echo $sidebar['media_contact']; ?>
  </div>

	<?php if(!empty($most_popular_posts)) : ?>
		<div class="sidebar__widget most-popuplar-posts">
			<h3><?php the_field('popular_articles_header'); ?></h3>
			<ul>
        <?php foreach($featured_post_repeater as $post) {
          $post_id = $post['post']->ID;
          $title = $post['post']->post_title;
          $post_url = get_permalink( $post_id );

          echo '<li><a href="' . $post_url . '" class="sidebar__widget__link">' . $title . '</a><li>';
        }
 ?>
			</ul>
		</div>
	<?php endif; ?>
</div>

<?php wp_reset_postdata(); ?>