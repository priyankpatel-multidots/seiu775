<?php
/**
 * The template for displaying all posts of category.
 *
 * This is the template that displays all posts of the category by default.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package seiu
 */

get_header();

// if (current_user_can('read_membership')) :
?>

	<main id="primary" class="site-main category">
		<div class="page-header">
			<div class="container container--md">
				<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
			</div>
		</div>
		<section>
			<div class="container container--md">
				<?php
				while ( have_posts() ) :
					the_post();
				endwhile; // End of the loop.
				?>
			</div>
		</section>
	</main><!-- #main -->

<?php
// endif;
// get_sidebar();
get_footer();
