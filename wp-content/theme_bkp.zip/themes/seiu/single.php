<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package seiu
 */

get_header();


$post_id = get_the_ID();
wpb_set_post_views($post_id); //set meta key for post view.

$category = get_the_terms($post_id, 'category')[0];

$post_date = get_the_date();

?>

	<main id="primary" class="site-main page-sidebar">
		<header class="page-header">
			<div class="container container--md">
        <?php
        if ( is_singular() ) :
          the_title( '<h1 class="entry-title">', '</h1>' );
        else :
          the_title( '<h1 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h1>' );
        endif;
        ?>
			</div>
		</header><!-- .entry-header -->

		<div class="page-sidebar__content">
			<div class="container container--md">
	    	<div class="main-content">

	    		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <?php $news_source = get_field('news_source');  ?>
            <?php if ($news_source['source_name'] || $news_source['show_post_date']): ?><p
              class="post__date"><?php if ($news_source['source_name']): ?><?php if ($news_source['source_link']): ?><a href="<?php echo $news_source['source_link']; ?>"><?php endif; ?><?php echo $news_source['source_name']; ?><?php if ($news_source['source_link']): ?></a><?php endif; ?><?php if ($news_source['show_post_date']): ?> | <?php endif; ?><?php endif; ?><?php if ($news_source['show_post_date']): ?><?php echo $post_date; ?><?php endif; ?>
              </p><?php endif; ?>

	    			<?php

								seiu_post_thumbnail();
						?>

						<div class="entry-content">
							<?php
								while ( have_posts() ) :
									the_post();
									the_content();
								endwhile; // End of the loop.
							?>
						</div>
					</article>
				</div>

				<?php
					include( locate_template( 'template-parts/sidebar.php'));
		    ?>
			</div>
		</div>
<!--
		<div class="post-navigation-wrapper">
			<div class="container container--md">
				<?php
					the_post_navigation(
						array(
							'prev_text' => '<span class="nav-subtitle">' . esc_html__( 'Previous:', 'seiu' ) . '</span> <span class="nav-title">%title</span>',
							'next_text' => '<span class="nav-subtitle">' . esc_html__( 'Next:', 'seiu' ) . '</span> <span class="nav-title">%title</span>',
						)
					);
				?>		
			</div>
		</div>
		-->
	</main><!-- #main -->

<?php
// get_sidebar();
get_footer();
