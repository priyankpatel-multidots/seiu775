module.exports = {
  plugins: {
    'autoprefixer': {}
  }
}
