const $ = jQuery;
console.log('IN MEMBERINFO');
document.addEventListener( 'DOMContentLoaded', () => {
	// Equal height for all posts.
	let highestBox = 0;
	$( '.membership-info .membership-info--list-item' ).each( function() {
		$( 'h3.title', this ).each( function() {
			if ( $( this ).height() > highestBox ) {
				highestBox = $( this ).height();
			}
		} );
	} );
	$( '.membership-info .membership-info--list-item h3.title' ).height( highestBox );

	highestBox = 0;
	$( '.cards-grid .cards-grid--list--item' ).each( function() {
		$( '.description', this ).each( function() {
			if ( $( this ).height() > highestBox ) {
				highestBox = $( this ).height();
			}
		} );
	} );
	$( '.cards-grid .cards-grid--list--item .description' ).height( highestBox );

	highestBox = 0;
	$( '.action-alert--content-wrapper .action-alert--container .action-alert--content' ).each( function() {
		$( '.description', this ).each( function() {
			if ( $( this ).height() > highestBox ) {
				highestBox = $( this ).height();
			}
		} );
	} );
	$( '.action-alert--content-wrapper .action-alert--container .action-alert--content .description' ).height( highestBox );

	const stickyHeight = getStickyElementsHeight();
	$( '#member-info-modal' ).css( 'height', `calc(100vh - ${stickyHeight}px )` );

	$( document ).on( 'click', 'a[rel^="modal:"]', function( event ) {
		const target = $( this.hash );
		if ( '' !== target && null !== target ) {
			event.preventDefault();
			$( $( this ).attr( 'href' ) ).css( 'top', stickyHeight ).removeClass( 'd-none' );
			$( 'body' ).addClass( 'modal-visible' );
		}
	} );

	$( '#member-info-modal .close-panel--inner svg' ).click( function() {
		$( '#member-info-modal' ).addClass( 'd-none' );
		$( 'body' ).removeClass( 'modal-visible' );
	});

	$( '#member-info-modal .member-info-panel #member-info--update > div > .edit-icon' ).click( function() {
		const elemInstance = $( this );
		elemInstance.parent().toggleClass( 'edit-enabled' );
		setTimeout( function() {
			elemInstance.siblings( '.input' ).trigger( 'focus' );
			SetCaretAtEnd( elemInstance.siblings( '.input' ).get( 0 ) );
		}, 100 );
	});

	$( document ).on( 'submit', '#member-info-modal form#member-info--update', function( event ) {
		event.preventDefault();
		const requestObject = {
			members: [ {
				status: 'update',
				memberIad: $( 'input[name=memberId]' ).val(),
			} ],
		};
		$( '.input-control', this ).each( function() {
			const value     = $( this ).children( '.input' ).val(),
				placeholder = $( this ).children( '.placeholder' ).text(),
				id          = $( this ).children( '.input' ).attr( 'name' );
			if ( value !== placeholder ) {
				requestObject.members[0][id] = value;
			}
		} );
	$.ajax( {
		url: 'https://bigtest-bigtest-seiu775.cs24.force.com/services/apexrest/WordPressAPI/MemberInfo/',
		type: 'POST',
		crossDomain: true,
		data: JSON.stringify( requestObject ),
		dataType: 'jsonp',
		success: function( response ) {
			console.log( response );
		},
	} )
	});

});

function getStickyElementsHeight() {
	let stickyHeight = 0;
	const elemAdminbar = $( '#wpadminbar:visible' ),
		elemAlertbar = $( '.site-header .site-header__alert-banner:visible' ),
		elemTopNav = $( '.site-header--top.top-menu:visible' ),
		elemMainNav = $( 'body.logged-in.members-nav .site-header__inner:visible' );

	if (elemAdminbar.length && elemAdminbar.isInViewport()) {
		stickyHeight += elemAdminbar.outerHeight();
	}

	if (elemAlertbar.length && elemAlertbar.isInViewport()) {
		stickyHeight += elemAlertbar.outerHeight();
	}

	if (elemTopNav.length && elemTopNav.isInViewport()) {
		stickyHeight += elemTopNav.outerHeight();
	}

	if (elemMainNav.length && elemMainNav.isInViewport()) {
		stickyHeight += elemMainNav.outerHeight();
	}

	return stickyHeight;
}

function SetCaretAtEnd(elem) {
	var elemLen = elem.value.length;
	// For IE Only
	if (document.selection) {
		// Set focus
		elem.focus();
		// Use IE Ranges
		var oSel = document.selection.createRange();
		// Reset position to 0 & then set at end
		oSel.moveStart( 'character', -elemLen);
		oSel.moveStart( 'character', elemLen);
		oSel.moveEnd( 'character', 0);
		oSel.select();
	} else if (elem.selectionStart || elem.selectionStart == '0' ) {
		// Firefox/Chrome
		elem.selectionStart = elemLen;
		elem.selectionEnd = elemLen;
		elem.focus();
	}
}

$.fn.isInViewport = function(predefined_scroll = 0) {
	var elementTop = $(this).offset().top + predefined_scroll;
	var elementBottom = elementTop + $(this).outerHeight();
	var viewportTop = $(window).scrollTop();
	var viewportBottom = viewportTop + $(window).height();
	return elementBottom > viewportTop && elementTop < viewportBottom;
};